import reflex as rx

config = rx.Config(
    app_name="app",
    api_url="https://gkalstest.netlify.app:8000"
)